EAR_LOCATION="$JBOSS_HOME/standalone/deployments/ATGProduction_Module/ATG_Prod.ear"
OJDBC_LOCATION="$JBOSS_HOME/standalone/deployments/atg_production_lockserver/ojdbc7.jar"
SERVER_NAME="atg_production_module_server"

rm -r $EAR_LOCATION

$DYNAMO_HOME/bin/runAssembler -jboss -prependJars $OJDBC_LOCATION -server $SERVER_NAME $EAR_LOCATION -m Store.EStore.International DafEar.Admin DPS DSS ContentMgmt DCS.PublishingAgent DCS.AbandonedOrderServices ContentMgmt.Endeca.Index DCS.Endeca.Index Store.Endeca.Index DAF.Endeca.Assembler DCS.Endeca.Index.SKUIndexing Store.Storefront Store.EStore.International Store.Recommendations Store.Mobile Store.Endeca.International Store.Storefront.NoPublishing Store.Fulfillment Store.KnowledgeBase.International Store.Mobile.Recommendations Store.Mobile.International PublishingAgent Store.Recommendations.International Store.Storefront.NoPublishing.International DafEar ATGCRS.atg_module
