$JBOSS_HOME//bin/standalone.sh --server-config=ATGProd_Module.xml -Datg.dynamo.layers=CustomLayer
