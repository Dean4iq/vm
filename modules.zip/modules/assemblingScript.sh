#!/bin/bash
MODULE_ATG11_ROOT=$DYNAMO_ROOT/ATGCRS/atg_module
MODULE_SOURCES=/apps/modules/ATGCRS/atg_module
EAR_LOCATION=$JBOSS_HOME/standalone/deployments/ATGProduction_Module/ATG_Prod.ear

rm -r $MODULE_ATG11_ROOT

mkdir -p $MODULE_ATG11_ROOT/config
mkdir -p $MODULE_ATG11_ROOT/configlayers/custom_layer
mkdir -p $MODULE_ATG11_ROOT/lib

#cp -avr $MODULE_SOURCES/src/rebel.xml $MODULE_SOURCES/lib/classes

#javac -d $MODULE_SOURCES/lib -sourcepath $MODULE_SOURCES/src $MODULE_SOURCES/src/atg/custom/CustomClass.java
#javac -d $MODULE_SOURCES/lib -sourcepath $MODULE_SOURCES/src $MODULE_SOURCES/src/atg/custom/ScopedClass.java
#javac -d $MODULE_SOURCES/lib -sourcepath $MODULE_SOURCES/src $MODULE_SOURCES/src/atg/test/DSBTest.java

jar cvf $MODULE_ATG11_ROOT/config/config.jar -C $MODULE_SOURCES/config/ .
jar cvf $MODULE_ATG11_ROOT/configlayers/custom_layer/config.jar -C $MODULE_SOURCES/configlayers/custom_layer .
jar cvf $MODULE_ATG11_ROOT/lib/classes.jar -C $MODULE_SOURCES/lib/classes .

cp -avr $MODULE_SOURCES/META-INF $MODULE_ATG11_ROOT
cp -avr $MODULE_SOURCES/j2ee $MODULE_ATG11_ROOT
