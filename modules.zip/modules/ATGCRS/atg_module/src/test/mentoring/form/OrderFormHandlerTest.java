package mentoring.form;

import atg.commerce.CommerceException;
import atg.commerce.order.CommerceItemManager;
import atg.commerce.order.Order;
import atg.commerce.order.SimpleOrderManager;
import atg.commerce.order.purchase.AddCommerceItemInfo;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.class)
public class OrderFormHandlerTest {
    private OrderFormHandler orderFormHandler;
    private static OrderDetails orderDetails;

    @Mock
    private SimpleOrderManager orderManager;
    @Mock
    private DynamoHttpServletRequest request;
    @Mock
    private DynamoHttpServletResponse response;
    @Mock
    private CommerceItemManager itemManager;
    @Mock
    private RepositoryItem repositoryItem;
    @Mock
    private Order order;

    private AddCommerceItemInfo[] commerceItemInfos;

    @BeforeClass
    public static void setObjects() {
        orderDetails = new OrderDetails();

        orderDetails.setOrderId("o4563");
        orderDetails.setNumberOfProducts(456L);
        orderDetails.setEmail("qwe@rty.cc");
    }

    @Before
    public void initCases() throws ServletException, IOException, RepositoryException, NamingException, CommerceException {
        MockitoAnnotations.initMocks(this);

        setUpPreAddItem();
    }

    private void setUpPreAddItem() throws RepositoryException, CommerceException, ServletException, IOException {
        setArrayOfAddCommerceItemInfo();
        restrictMockClasses();
    }

    private void setArrayOfAddCommerceItemInfo() {
        AddCommerceItemInfo addCommerceItemInfo1 = new AddCommerceItemInfo();
        addCommerceItemInfo1.setProductId("xprod12");
        addCommerceItemInfo1.setCatalogRefId("2334");

        AddCommerceItemInfo addCommerceItemInfo2 = new AddCommerceItemInfo();
        addCommerceItemInfo2.setProductId("xprod13");
        addCommerceItemInfo2.setCatalogRefId("2344");

        AddCommerceItemInfo addCommerceItemInfo3 = new AddCommerceItemInfo();
        addCommerceItemInfo3.setProductId("xprod234");
        addCommerceItemInfo3.setCatalogRefId("1480");

        commerceItemInfos = new AddCommerceItemInfo[]{addCommerceItemInfo1, addCommerceItemInfo2, addCommerceItemInfo3};
    }

    private void restrictMockClasses() throws CommerceException, ServletException, IOException, RepositoryException {
        orderFormHandler = Mockito.spy(new OrderFormHandler());
        orderFormHandler.setOrderManager(orderManager);

        Mockito.doNothing().when(orderManager).updateOrder(any(Order.class));
        Mockito.doNothing().when(orderFormHandler).callSuperAddItemToOrder(any(DynamoHttpServletRequest.class), any(DynamoHttpServletResponse.class));

        Mockito.doReturn(itemManager).when(orderFormHandler).getCommerceItemManager();
        Mockito.when(orderFormHandler.getCommerceItemManager().getProduct("xprod12", "2334")).thenReturn(Mockito.mock(RepositoryItem.class));
        Mockito.when(orderFormHandler.getCommerceItemManager().getProduct("xprod13", "2344")).thenReturn(Mockito.mock(RepositoryItem.class));
        Mockito.when(orderFormHandler.getCommerceItemManager().getProduct("xprod234", "1480")).thenReturn(Mockito.mock(RepositoryItem.class));

        Mockito.when(((RepositoryItem) orderFormHandler.getCommerceItemManager().getProduct("xprod12", "2334"))
                .getPropertyValue("hazardous")).thenReturn(false);
        Mockito.when(((RepositoryItem) orderFormHandler.getCommerceItemManager().getProduct("xprod13", "2344"))
                .getPropertyValue("hazardous")).thenReturn(true);
        Mockito.when(((RepositoryItem) orderFormHandler.getCommerceItemManager().getProduct("xprod234", "1480"))
                .getPropertyValue("hazardous")).thenReturn(false);

        Mockito.when(orderFormHandler.getProfile()).thenReturn(repositoryItem);

        Mockito.doReturn(order).when(orderFormHandler).getOrder();
        Mockito.when(orderFormHandler.getOrder().getId()).thenReturn(orderDetails.getOrderId());
        Mockito.when(orderFormHandler.getOrder().getTotalCommerceItemCount()).thenReturn(orderDetails.getNumberOfProducts());
        Mockito.when(orderFormHandler.getProfile().getItemDisplayName()).thenReturn(orderDetails.getEmail());
    }

    @Test
    public void testAnonymousCasePreAddItem() throws ServletException, IOException {
        Mockito.when(orderFormHandler.getProfile().getPropertyValue("securityStatus")).thenReturn(2);
        Mockito.when(orderFormHandler.getItems()).thenReturn(commerceItemInfos);
        Mockito.when(orderFormHandler.getProfile().getPropertyValue("licenseNumber")).thenReturn("F45G-23FD-QQ4M-K56N");

        orderFormHandler.preAddItemToOrder(request, response);

        assertTrue(orderFormHandler.getFormError());
    }

    @Test
    public void testLicenseAbsentCasePreAddItem() throws ServletException, IOException {
        Mockito.when(orderFormHandler.getProfile().getPropertyValue("securityStatus")).thenReturn(4);
        Mockito.when(orderFormHandler.getItems()).thenReturn(commerceItemInfos);
        Mockito.when(orderFormHandler.getProfile().getPropertyValue("licenseNumber")).thenReturn(null);

        orderFormHandler.preAddItemToOrder(request, response);

        assertTrue(orderFormHandler.getFormError());
    }

    @Test
    public void successfulPreAddItemTestCase() throws ServletException, IOException {
        Mockito.when(orderFormHandler.getProfile().getPropertyValue("securityStatus")).thenReturn(4);
        Mockito.when(orderFormHandler.getItems()).thenReturn(commerceItemInfos);
        Mockito.when(orderFormHandler.getProfile().getPropertyValue("licenseNumber")).thenReturn("F45G-23FD-QQ4M-K56N");

        orderFormHandler.preAddItemToOrder(request, response);

        assertFalse(orderFormHandler.getFormError());
    }

    @Test
    public void testUpdateItemsToOrderDetails() throws ServletException, IOException {
        orderFormHandler.setOrderDetails(new OrderDetails());
        orderFormHandler.updateOrder(order, "SomeMSG", request, response);

        assertEquals(orderDetails, orderFormHandler.getOrderDetails());
        assertEquals(orderDetails.hashCode(), orderFormHandler.getOrderDetails().hashCode());
    }
}
