package mentoring.test;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import java.io.IOException;

/**
 * Created by oracle on 6/24/19.
 */
public class DSBTest2 extends DynamoServlet {
    public DSBTest2() {
    }

    public void service(DynamoHttpServletRequest request,
                        DynamoHttpServletResponse response)
            throws ServletException, IOException {
        ServletOutputStream out = response.getOutputStream();
        out.println("Here's the value of the parameter 'storename':");
        request.serviceParameter("storename", request, response);
    }
}
