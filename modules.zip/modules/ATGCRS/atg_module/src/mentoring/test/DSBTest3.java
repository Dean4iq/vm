package mentoring.test;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

import javax.servlet.ServletException;
import java.io.IOException;

/**
 * Created by oracle on 6/24/19.
 */
public class DSBTest3 extends DynamoServlet {
    public DSBTest3 () {}

    public void service (DynamoHttpServletRequest request,
                         DynamoHttpServletResponse response)
            throws ServletException, IOException
    {
        request.setParameter ("goods", "Golf Balls");
        request.serviceParameter ("storename", request, response);
    }
}
