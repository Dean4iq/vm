package mentoring.test;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import java.io.IOException;

/**
 * Created by oracle on 6/24/19.
 */
public class DSBStoreTest extends DynamoServlet{
    public void service (DynamoHttpServletRequest request,
                         DynamoHttpServletResponse response)
            throws ServletException, IOException
    {
        String storename = request.getParameter ("storename");
        if (storename == null) storename = "No-Name's";

        ServletOutputStream out = response.getOutputStream ();
        out.println ("<h1>Welcome to " + storename + "</h1>");
    }
}
