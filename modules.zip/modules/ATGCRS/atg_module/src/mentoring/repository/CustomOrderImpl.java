package mentoring.repository;

import atg.projects.store.order.StoreOrderImpl;

public class CustomOrderImpl extends StoreOrderImpl {
    private Boolean licenseCheckRequired;
    private String color;

    public Boolean getLicenseCheckRequired() {
        return licenseCheckRequired;
    }

    public void setLicenseCheckRequired(Boolean licenseCheckRequired) {
        addChangedProperty("licenseCheckRequired");
        this.licenseCheckRequired = licenseCheckRequired;
    }

    public String getColor() {
        return (String) getRepositoryItem().getPropertyValue("color");
        //return color;
    }

    public void setColor(String color) {
        getRepositoryItem().setPropertyValue("color", color);
        /*addChangedProperty("color");
        this.color = color;*/
    }
}
