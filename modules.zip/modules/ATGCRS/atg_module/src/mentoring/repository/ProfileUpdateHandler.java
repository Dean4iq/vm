package mentoring.repository;

import atg.droplet.DropletException;
import atg.projects.store.profile.StoreProfileFormHandler;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import mentoring.form.annotation.IsValid;
import mentoring.form.validator.ValidationProcessor;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class ProfileUpdateHandler extends StoreProfileFormHandler {
    @IsValid(implClass = "dynamo:/custom/form/form/LicenseNumberValidator")
    private String licenseNumber;

    private ValidationProcessor validationProcessor;

    @Override
    protected void postUpdateUser(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        super.postUpdateUser(pRequest, pResponse);

        try {
            licenseNumber = (String) this.getProfile().getPropertyValue("licenseNumber");

            Map<String, List<String>> errors = validationProcessor.validate(this);

            if (errors.isEmpty()) {
                this.getProfile().setPropertyValue("licenseNumber", licenseNumber);
            } else {
                for (String key : errors.keySet()) {
                    for (String message : errors.get(key)) {
                        addFormException(new DropletException(message));
                    }
                }
            }
        } catch (IllegalAccessException | InstantiationException | NamingException e) {
            e.printStackTrace();
        }
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    public ValidationProcessor getValidationProcessor() {
        return validationProcessor;
    }

    public void setValidationProcessor(ValidationProcessor validationProcessor) {
        this.validationProcessor = validationProcessor;
    }
}
