package mentoring.custom;

public class ScopedClass {
    private String globalValue;
    private String sessionValue;
    private String requestValue;

    public String getGlobalValue() {
        return globalValue;
    }

    public void setGlobalValue(String globalValue) {
        this.globalValue = globalValue;
    }

    public String getSessionValue() {
        return sessionValue;
    }

    public void setSessionValue(String sessionValue) {
        this.sessionValue = sessionValue;
    }

    public String getRequestValue() {
        return requestValue;
    }

    public void setRequestValue(String requestValue) {
        this.requestValue = requestValue;
    }

    public int getSystemIdHashCode() {
        return System.identityHashCode(this);
    }

    @java.lang.Override
    public java.lang.String toString() {
        return "ScopedClass{" +
                "globalValue='" + globalValue + '\'' +
                ", sessionValue='" + sessionValue + '\'' +
                ", requestValue='" + requestValue + '\'' +
                '}';
    }
}