package mentoring.droplets;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

import javax.servlet.ServletException;
import java.io.IOException;

public class MapDroplet2 extends DynamoServlet {
    private WeekDaysMapper mapper;

    public MapDroplet2() {
    }

    public void service(DynamoHttpServletRequest request,
                        DynamoHttpServletResponse response)
            throws ServletException, IOException {
        String key = request.getParameter("day");

        if (mapper.getWeekDaysMap().containsKey(key)) {
            request.setParameter("dayType", mapper.getWeekDaysMap().get(key));
            request.serviceParameter("matched", request, response);
        } else {
            request.serviceParameter("unmatched", request, response);
        }
    }

    public WeekDaysMapper getMapper() {
        return mapper;
    }

    public void setMapper(WeekDaysMapper mapper) {
        this.mapper = mapper;
    }
}
