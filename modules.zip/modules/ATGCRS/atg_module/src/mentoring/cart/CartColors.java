package mentoring.cart;

import java.util.Map;

public class CartColors {
    private Map<String,String> availableColorCodes;

    public Map<String, String> getAvailableColorCodes() {
        return availableColorCodes;
    }

    public void setAvailableColorCodes(Map<String, String> availableColorCodes) {
        this.availableColorCodes = availableColorCodes;
    }
}
