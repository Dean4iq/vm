package mentoring.form;

import atg.droplet.DropletFormException;
import atg.droplet.GenericFormHandler;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import mentoring.form.validator.ValidationProcessor;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class OwnFormHandler extends GenericFormHandler {
    private String successURL;
    private String errorURL;

    private OrderDetailsDto orderDetailsDto;

    private ValidationProcessor validationProcessor;

    public OwnFormHandler() {
        this.orderDetailsDto = new OrderDetailsDto();
    }

    public boolean handleValidate(DynamoHttpServletRequest request, DynamoHttpServletResponse response)
            throws IOException, ServletException {
        validateDto();

        return checkFormRedirect(successURL, errorURL, request, response);
    }

    private void validateDto() {
        try {
            Map<String, List<String>> errors = validationProcessor.validate(orderDetailsDto);

            for (Map.Entry<String, List<String>> entry : errors.entrySet()) {
                for (String errorMsg : entry.getValue()) {
                    addFormException(new DropletFormException(errorMsg,
                            "OwnFormHandler." + entry.getKey()));
                }
            }
        } catch (IllegalAccessException | InstantiationException | NamingException e) {
            e.printStackTrace();
        }
    }

    public String getSuccessURL() {
        return successURL;
    }

    public void setSuccessURL(String successURL) {
        this.successURL = successURL;
    }

    public String getErrorURL() {
        return errorURL;
    }

    public void setErrorURL(String errorURL) {
        this.errorURL = errorURL;
    }

    public OrderDetailsDto getOrderDetailsDto() {
        return orderDetailsDto;
    }

    public void setOrderDetailsDto(OrderDetailsDto orderDetailsDto) {
        this.orderDetailsDto = orderDetailsDto;
    }

    public ValidationProcessor getValidationProcessor() {
        return validationProcessor;
    }

    public void setValidationProcessor(ValidationProcessor validationProcessor) {
        this.validationProcessor = validationProcessor;
    }
}
