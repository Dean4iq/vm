package mentoring.form;

import atg.commerce.order.*;
import atg.commerce.order.processor.ProcSaveOrderObject;
import atg.commerce.order.purchase.AddCommerceItemInfo;
import atg.droplet.DropletException;
import atg.droplet.DropletFormException;
import atg.projects.store.mobile.order.purchase.MobileStoreCartFormHandler;
import atg.repository.*;
import atg.service.lockmanager.ClientLockManager;
import atg.service.lockmanager.DeadlockException;
import atg.service.lockmanager.LockManagerException;
import atg.service.pipeline.*;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import mentoring.form.pipeline.processor.ProcCheckOrderOnLicenseRequire;
import mentoring.repository.CustomOrderImpl;

import javax.servlet.ServletException;
import java.io.IOException;
import java.util.List;

public class OrderFormHandler extends MobileStoreCartFormHandler {
    private final String HAZARDOUS_PROP = "hazardous";
    private final String HAZARDOUS_ITEM_RESTRICTION_MSG = "You are trying to add a hazardous item whilst you do not have a wired license number in your profile";
    private final String LICENSE_NUMBER_PROP = "licenseNumber";

    private OrderDetails orderDetails;

    @Override
    public void preAddItemToOrder(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        callSuperAddItemToOrder(pRequest, pResponse);

        for (AddCommerceItemInfo ci : getItems()) {
            String productId = ci.getProductId();
            String catalogRefId = ci.getCatalogRefId();
            String licenseNumber = (String) getProfile().getPropertyValue(LICENSE_NUMBER_PROP);

            try {
                Boolean isHazardous = (Boolean) ((RepositoryItem) getCommerceItemManager().getProduct(productId, catalogRefId))
                        .getPropertyValue(HAZARDOUS_PROP);

                if (isHazardous && (Integer) getProfile().getPropertyValue("securityStatus") < 4) {
                    addFormException(new DropletException("You should be signed in to be able to add this item to cart"));
                    break;
                } else if (isHazardous && (licenseNumber == null || licenseNumber.isEmpty())) {
                    addFormException(new DropletException(HAZARDOUS_ITEM_RESTRICTION_MSG));
                    break;
                }
            } catch (RepositoryException e) {
                vlogError("Repo exception in order: {0}, productId: {1}, catalogRefId: {2}", getOrder().getId(), productId, catalogRefId);
            }
        }
    }

    public void callSuperAddItemToOrder(DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {
        super.preAddItemToOrder(request, response);
    }

    @Override
    protected void updateOrder(Order pOrder, String pMsgId, DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse)
            throws ServletException, IOException {
        /*ClientLockManager lockManager = getLocalLockManager();
        boolean lockAcquiredReserved = false;

        try {
            if (!lockManager.hasWriteLock(getOrder().getId(), Thread.currentThread())) {
                lockManager.acquireWriteLock(getOrder().getId(), Thread.currentThread());
                lockAcquiredReserved = true;
            }

            try {
                checkCartOnHazardousItem();

                super.updateOrder(pOrder, pMsgId, pRequest, pResponse);
                operateWithOrderDetails();
            } catch (InvalidParameterException | CommerceItemNotFoundException | RepositoryException e) {
                vlogError(e, "Error happened in update order handler. Order: {0}, profileId: {1}", getOrder().getId(), getProfile().getRepositoryId());
            } finally {
                if (lockAcquiredReserved) {
                    lockManager.releaseWriteLock(getOrder().getId(), Thread.currentThread());
                }
            }
        } catch (DeadlockException | LockManagerException e) {
            vlogError(e, "Error happened in update order handler. Order: {0}, profileId: {1}", getOrder().getId(), getProfile().getRepositoryId());
        }*/

        super.updateOrder(pOrder, pMsgId, pRequest, pResponse);
        operateWithOrderDetails();
    }

    private void operateWithOrderDetails() {
        String orderID = getOrder().getId();
        Long numberOfProducts = getOrder().getTotalCommerceItemCount();
        String email = getProfile().getItemDisplayName();

        orderDetails.setOrderId(orderID);
        orderDetails.setNumberOfProducts(numberOfProducts);
        orderDetails.setEmail(email);
    }

    /*private void checkCartOnHazardousItem() throws InvalidParameterException, CommerceItemNotFoundException, RepositoryException {
        List<CommerceItem> ci = getOrder().getCommerceItems();
        boolean licenseRequired = false;

        for (CommerceItem item : ci) {
            RepositoryItem product = (RepositoryItem) item.getAuxiliaryData().getProductRef();
            if ((Boolean) product.getPropertyValue(HAZARDOUS_PROP)) {
                licenseRequired = true;
                break;
            }
        }

        ((CustomOrderImpl) getOrder()).setLicenseCheckRequired(licenseRequired);
    }*/

    public OrderDetails getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(OrderDetails orderDetails) {
        this.orderDetails = orderDetails;
    }
}
