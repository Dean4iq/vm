package mentoring.form.validator;

import java.util.ArrayList;
import java.util.List;

public class OrderIdValidator implements Validator {
    @Override
    public List<String> validate(Object item) {
        List<String> errorList = new ArrayList<>();

        if ((item == null) || item.toString().isEmpty()) {
            errorList.add("You should fill out OrderID field!");
        }

        return errorList;
    }
}
