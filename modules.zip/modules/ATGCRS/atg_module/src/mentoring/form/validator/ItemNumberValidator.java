package mentoring.form.validator;

import java.util.ArrayList;
import java.util.List;

public class ItemNumberValidator implements Validator {
    private int digitsInItems;
    private String numberRegEx = "\\d*";

    @Override
    public List<String> validate(Object item) {
        List<String> errorList = new ArrayList<>();

        if (item == null || item.toString().isEmpty()) {
            errorList.add("Fill number of items field with some number!");
        } else if (!item.toString().matches(numberRegEx)) {
            errorList.add("Set number of items (Should be number)");
        } else if (!(item.toString().length() >= digitsInItems)) {
            errorList.add("Set correct number of items (Should contain equal or more than "
                    + digitsInItems
                    + " digits)");
        }

        return errorList;
    }

    public int getDigitsInItems() {
        return digitsInItems;
    }

    public void setDigitsInItems(int digitsInItems) {
        this.digitsInItems = digitsInItems;
    }

    public String getNumberRegEx() {
        return numberRegEx;
    }

    public void setNumberRegEx(String numberRegEx) {
        this.numberRegEx = numberRegEx;
    }
}
