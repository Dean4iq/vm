package mentoring.form.validator;

import java.util.ArrayList;
import java.util.List;

public class EmailValidator implements Validator {
    private String emailRegEx;

    @Override
    public List<String> validate(Object item) {
        List<String> errorList = new ArrayList<>();

        if (item == null || item.toString().isEmpty()) {
            errorList.add("Fill the email field!");
        } else if (!item.toString().matches(emailRegEx)) {
            errorList.add("Email is incorrect!");

            if (!item.toString().contains("@")) {
                errorList.add(" - WHERE IS '@' symbol?!!!");
            } else {
                if (item.toString().substring(0, item.toString().indexOf("@")).isEmpty()) {
                    errorList.add(" - WHERE IS THE IDENTITY?!!");
                }

                String serviceName = item.toString().substring(item.toString().indexOf('@') + 1);

                if (serviceName.isEmpty()) {
                    errorList.add(" - WHERE IS SERVICE NAME?!!");
                } else {
                    if (!serviceName.contains(".") || serviceName.substring(serviceName.indexOf('.') + 1).isEmpty()) {
                        errorList.add(" - WHERE IS DOMAIN NAME?!!");
                    }
                    if (serviceName.contains(".") && serviceName.substring(0, serviceName.indexOf(".")).isEmpty()) {
                        errorList.add(" - WHERE IS THE SERVER NAME?!!");
                    }
                }
            }
        }

        return errorList;
    }

    public String getEmailRegEx() {
        return emailRegEx;
    }

    public void setEmailRegEx(String emailRegEx) {
        this.emailRegEx = emailRegEx;
    }
}
