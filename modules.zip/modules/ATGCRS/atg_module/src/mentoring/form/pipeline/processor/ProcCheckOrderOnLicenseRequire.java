package mentoring.form.pipeline.processor;

import atg.commerce.order.CommerceItem;
import atg.commerce.order.CommerceItemNotFoundException;
import atg.commerce.order.InvalidParameterException;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.service.pipeline.PipelineProcessor;
import atg.service.pipeline.PipelineResult;
import mentoring.repository.CustomOrderImpl;

import java.util.List;
import java.util.Map;

public class ProcCheckOrderOnLicenseRequire implements PipelineProcessor {
    @Override
    public int runProcess(Object object, PipelineResult pipelineResult) throws Exception {
        Map items = (Map) object;
        CustomOrderImpl order = (CustomOrderImpl) items.get("Order");

        checkCartOnHazardousItem(order);

        return 1;
    }

    @Override
    public int[] getRetCodes() {
        return new int[]{1};
    }

    private void checkCartOnHazardousItem(CustomOrderImpl order) throws InvalidParameterException, CommerceItemNotFoundException, RepositoryException {
        List<CommerceItem> ci = order.getCommerceItems();
        boolean licenseRequired = false;

        for (CommerceItem item : ci) {
            RepositoryItem product = (RepositoryItem) item.getAuxiliaryData().getProductRef();
            if ((Boolean) product.getPropertyValue("hazardous")) {
                licenseRequired = true;
                break;
            }
        }

        order.setLicenseCheckRequired(licenseRequired);
    }
}
