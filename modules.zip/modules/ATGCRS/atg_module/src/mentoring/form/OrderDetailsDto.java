package mentoring.form;

import mentoring.form.annotation.IsValid;

public class OrderDetailsDto {
    @IsValid(implClass = "dynamo:/custom/form/form/OrderIdValidator")
    private String orderId;

    @IsValid(implClass = "dynamo:/custom/form/form/ItemNumberValidator")
    private String numberOfProducts;

    @IsValid(implClass = "dynamo:/custom/form/form/EmailValidator")
    private String email;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getNumberOfProducts() {
        return numberOfProducts;
    }

    public void setNumberOfProducts(String numberOfProducts) {
        this.numberOfProducts = numberOfProducts;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
