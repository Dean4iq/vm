package mentoring.form.validator;

import mentoring.form.annotation.IsValid;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ValidationProcessor {
    public Map<String, List<String>> validate(Object object) throws IllegalAccessException, InstantiationException, NamingException {
        Map<String, List<String>> errorMap = new HashMap<>();
        Field[] fields = object.getClass().getDeclaredFields();

        for (Field field : fields) {
            if (field.isAnnotationPresent(IsValid.class)) {
                IsValid annotation = field.getAnnotation(IsValid.class);

                Validator validator = (Validator) new InitialContext().lookup(annotation.implClass());

                field.setAccessible(true);

                List<String> errorMsg = validator.validate(field.get(object));

                if (!errorMsg.isEmpty()) {
                    String pathToField = object.getClass().getSimpleName() + "." + field.getName();
                    errorMap.put(pathToField, errorMsg);
                }
            }
        }

        return errorMap;
    }
}
