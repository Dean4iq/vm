package mentoring.droplets;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

import javax.servlet.ServletException;
import java.io.IOException;

public class MapDroplet extends DynamoServlet {
    private WeekDaysMapper mapper;
    private String key;
    private boolean matched;
    private boolean unmatched;

    public MapDroplet() {
    }

    public void service(DynamoHttpServletRequest request,
                        DynamoHttpServletResponse response)
            throws ServletException, IOException {
        for (String key : mapper.getWeekDaysMap().keySet()) {
            request.setParameter("day", key);
            request.setParameter("dayType", mapper.getWeekDaysMap().get(key));
            request.serviceParameter("dayDescriptor", request, response);
        }
    }

    public WeekDaysMapper getMapper() {
        return mapper;
    }

    public void setMapper(WeekDaysMapper mapper) {
        this.mapper = mapper;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public boolean isMatched() {
        return matched;
    }

    public void setMatched(boolean matched) {
        this.matched = matched;
    }

    public boolean isUnmatched() {
        return unmatched;
    }

    public void setUnmatched(boolean unmatched) {
        this.unmatched = unmatched;
    }
}
