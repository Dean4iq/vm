package mentoring.form.validator;

import java.util.List;

public interface Validator {
    List<String> validate(Object item);
}
