package mentoring.droplets;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

import javax.servlet.ServletException;
import java.io.IOException;

/**
 * Created by oracle on 6/24/19.
 */
public class WeekDaysDroplet extends DynamoServlet {
    private static final String MONDAY = "Monday";
    private static final String TUESDAY = "Tuesday";
    private static final String WEDNESDAY = "Wednesday";
    private static final String THURSDAY = "Thursday";
    private static final String FRIDAY = "Friday";
    private static final String SATURDAY = "Saturday";
    private static final String SUNDAY = "Sunday";

    private final String WORKING_DAY = "Workday";
    private final String HOLIDAY_DAY = "Holiday";

    private final String DAY_NOT_FOUND = "Sry, but Your input was incorrect";

    public WeekDaysDroplet() {
    }

    public void service(DynamoHttpServletRequest request,
                        DynamoHttpServletResponse response)
            throws ServletException, IOException {
        String day = request.getParameter("element");

        if (MONDAY.equals(day) || TUESDAY.equals(day) || WEDNESDAY.equals(day) || THURSDAY.equals(day) || FRIDAY.equals(day)) {
            request.setParameter("dayType", WORKING_DAY);
        } else if (SATURDAY.equals(day) || SUNDAY.equals(day)) {
            request.setParameter("dayType", HOLIDAY_DAY);
        } else {
            request.setParameter("dayType", DAY_NOT_FOUND);
        }

        request.serviceParameter("dayDescriptor", request, response);
    }
}
