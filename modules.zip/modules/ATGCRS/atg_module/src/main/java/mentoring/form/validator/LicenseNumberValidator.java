package mentoring.form.validator;

import java.util.ArrayList;
import java.util.List;

public class LicenseNumberValidator implements Validator {
    private String licenseNumberRegEx;

    @Override
    public List<String> validate(Object item) {
        List<String> errorList = new ArrayList<>();

        if (item != null && fieldContainsError(item.toString())) {
            errorList.add("License number should be in the following format: ****-****-****-****, where * is any number or letter in upper case");
        }

        return errorList;
    }

    private boolean fieldContainsError(String item) {
        return !item.matches(licenseNumberRegEx);
    }

    public String getLicenseNumberRegEx() {
        return licenseNumberRegEx;
    }

    public void setLicenseNumberRegEx(String licenseNumberRegEx) {
        this.licenseNumberRegEx = licenseNumberRegEx;
    }
}
