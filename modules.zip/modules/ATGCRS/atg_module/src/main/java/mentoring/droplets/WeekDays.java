package mentoring.droplets;

import java.util.List;

/**
 * Created by oracle on 6/24/19.
 */
public class WeekDays {
    private List<String> days;

    public List<String> getDays() {
        return days;
    }

    public void setDays(List<String> days) {
        this.days = days;
    }
}
