package mentoring.droplets;

import java.util.Map;

/**
 * Created by oracle on 6/25/19.
 */
public class WeekDaysMapper {
    private Map<String, String> weekDaysMap;

    public Map<String, String> getWeekDaysMap() {
        return weekDaysMap;
    }

    public void setWeekDaysMap(Map<String, String> weekDaysMap) {
        this.weekDaysMap = weekDaysMap;
    }
}
