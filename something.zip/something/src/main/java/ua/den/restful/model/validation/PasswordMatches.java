package ua.den.restful.model.validation;

import ua.den.restful.model.validation.validators.PasswordMatchesValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Constraint(validatedBy = PasswordMatchesValidator.class)
@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface PasswordMatches {
    String message() default "Age should be acceptable";
    String passwordField();
    String repeatedPasswordField();
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
