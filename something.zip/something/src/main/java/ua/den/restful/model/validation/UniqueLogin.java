package ua.den.restful.model.validation;

public @interface UniqueLogin {
}
