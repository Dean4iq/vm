package ua.den.restful.model.validation.validators;

import ua.den.restful.model.validation.PasswordMatches;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PasswordMatchesValidator implements ConstraintValidator<PasswordMatches, Object> {
    private String passwordField;
    private String repeatedPasswordField;

    @Override
    public void initialize(PasswordMatches constraintAnnotation) {
        this.passwordField = constraintAnnotation.passwordField();
        this.repeatedPasswordField = constraintAnnotation.repeatedPasswordField();
    }

    @Override
    public boolean isValid(Object object, ConstraintValidatorContext constraintValidatorContext) {
        Class classInstance = object.getClass();

        try {
            Object password = classInstance.getField(passwordField).get(object);
            Object repeatedPassword = classInstance.getField(repeatedPasswordField).get(object);

            return password.equals(repeatedPassword);
        } catch (IllegalAccessException | NoSuchFieldException e) {
            e.printStackTrace();
        }

        return false;
    }
}
