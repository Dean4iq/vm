package ua.den.restful.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import ua.den.restful.model.dto.UserRegistrationDTO;

import javax.validation.Valid;

@Controller
@RequestMapping("")
public class GuestController {
    @RequestMapping("")
    public String handleEmptyPath() {
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String getLoginPage() {
        return "guest/login";
    }

    @GetMapping("sign_up")
    public ModelAndView getSignUpPage() {
        ModelAndView modelAndView = new ModelAndView("guest/register_page");

        modelAndView.addObject("userData", new UserRegistrationDTO());

        return modelAndView;
    }

    @PostMapping("sign_up")
    public String signUpUser(@ModelAttribute(name = "userData") @Valid UserRegistrationDTO userDTO) {

        return "redirect:/home";
    }
}