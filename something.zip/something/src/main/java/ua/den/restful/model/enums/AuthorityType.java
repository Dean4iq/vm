package ua.den.restful.model.enums;

public enum AuthorityType {
    ROLE_ADMIN, ROLE_USER
}
