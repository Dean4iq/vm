package ua.den.restful.model.validation.validators;

import ua.den.restful.model.validation.Age;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.time.LocalDate;

public class AgeValidator implements ConstraintValidator<Age, LocalDate> {
    private int minAge;
    private int maxAge;

    @Override
    public void initialize(Age constraintAnnotation) {
        this.minAge = constraintAnnotation.minAge();
        this.maxAge = constraintAnnotation.maxAge();
    }

    @Override
    public boolean isValid(LocalDate passedDate, ConstraintValidatorContext constraintValidatorContext) {
        LocalDate currentLocalDate = LocalDate.now();

        return ((currentLocalDate.getYear() - passedDate.getYear() >= minAge)
                && (currentLocalDate.getYear() - passedDate.getYear() < maxAge));
    }
}
